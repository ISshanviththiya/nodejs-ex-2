var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

MongoClient.connect(url, function(err, db) {
Â  if (err) throw err;
  var dbo = db.db("nodemongo");
  //Create a collection name "customers":
Â  dbo.createCollection("songdetailsâ€‹", function(err, res) {
Â Â Â  if (err) throw err;
Â Â Â  console.log("Collection created!");
Â Â Â  db.close();
Â  });
});
